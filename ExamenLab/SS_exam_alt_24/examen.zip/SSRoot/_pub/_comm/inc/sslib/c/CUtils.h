#pragma once

// Ejemplo de c�digo C++ que puede ser llamado desde C o C++
#ifndef LIB_ESTATICA

#ifdef _LIB_EXPORTS_
#define LIB_API __declspec(dllexport)
#else
#define LIB_API __declspec(dllimport)
#endif
#else
#define LIB_API
#endif // !LIB_ESTATICA

#ifdef __cplusplus
// Compilaci�n condicional: esta parte solo se compila si se incluye desde un archivo .cpp
extern "C" {

#else

// Esta parte solo se compila si se incluye desde un archivo .c
#ifndef bool

// Esta parte solo se compila si no est� definido el tipo bool (algunos compiladores C no lo tienen)
typedef int bool;

#endif

#endif

bool  LIB_API CheckError(bool condicionError, int codigoSalida, const char* mensajeUsuario, ...);

#ifdef __cplusplus
}	// Tan solo sirve para cerrar la llave del extern "C"
#endif



#include <Windows.h>


