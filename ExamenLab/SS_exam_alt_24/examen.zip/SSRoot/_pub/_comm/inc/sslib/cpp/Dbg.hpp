#pragma once

#include <vector>
#include <string>
#include <Windows.h>

#include "Crono.hpp"

using namespace std;


namespace ss {
	class LIB_API Dbg
	{
	private:	// Opcional, por defecto todo es privado
		const char* cabeceraError = "ERROR";
		bool _salidaDepuracion; // Si es true, se env�a la salida a la ventana de depuraci�n
		bool _salidaPantalla; // Si es true, se env�a la salida a la consola de salida
		Crono crono;
		static bool _primerUsoClase; // Variable est�tica de clase
	public:
		const char* Vesion = "2024.10.07_00";
		Dbg(bool salidaPorPantalla = false, bool salidaPorDepuracion = true);
		~Dbg();

		/// <summary>
		/// Comprueba la condici�n de error que se le pasa en el primer argumento y actua en consecuencia
		/// </summary>
		/// <param name="condicionError"> Condici�n de error a comprobar. Si false no hace nada. Si true, USA los par�metros que sigue...</param>
		/// <param name="codigoSalida"> Si condicionError es true, termina el programa si este par�metro es distinto de 0</param>
		/// <param name="mensajeUsuario"> Si condicionError es true, imprime un mensaje de error como lo har�a un printf: 
		/// mensajeUsuario es la cadena de formato, y los siguientes par�metros se usan como la lista opcional de par�metros de un printf</param>
		/// <param name="">Lista de par�metros opcionales</param>
		/// <returns>devuelve el valor que se le pasa en condicionError</returns>
		bool CheckError(bool condicionError, int codigoSalida, const char* mensajeUsuario, ...);

		/// <summary>
		/// Comprueba la condici�n de error que se le pasa en el primer argumento y actua en consecuencia
		/// </summary>
		/// <param name="condicionError"> Condici�n de error a comprobar. Si false no hace nada. Si true, USA los par�metros que sigue...</param>
		/// <param name="mensajeUsuario"> Si condicionError es true, imprime un mensaje de error como lo har�a un printf: 
		/// mensajeUsuario es la cadena de formato, y los siguientes par�metros se usan como la lista opcional de par�metros de un printf</param>
		/// <param name="">Lista de par�metros opcionales</param>
		/// <returns>devuelve el valor que se le pasa en condicionError</returns>
		bool CheckError(bool condicionError, const char* mensajeUsuario, ...);

		/// <summary>
		/// Inicia medici�n de tiempos.
		/// </summary>
		/// <returns></returns>
		bool CronoInicio() {	// Ejemplo de m�todo interno (definido en el propio archivo .h)
			return crono.Inicio();
		}
		/// <summary>
		/// Lee segundos transcurridos desde la �ltima llamada a CronoInicio.
		/// </summary>
		/// <returns></returns>
		double CronoLee() {	// Ejemplo de m�todo interno (definido en el propio archivo .h)
			return crono.Lee();
		}
		/// <summary>
		/// Funciona igual que printf, pero muestra la salida solo por la ventana de salida (depuraci�n) y por consola (opcional)
		/// </summary>
		int DbgPrint(const char* formatString, ...);

	};

} // Fin namespace
