#include <stdio.h>
#include <conio.h>
#include <locale.h>
#include <iostream>


using namespace std;

int main(int argc, char *argv[], char *envp[])
{
	setlocale(LC_ALL, "Spanish");
	
	// Pendiente: Modificar para imprimir argumentos del programa 

	for (int i = 0; envp[i] != 0; i++)
	{
		cout << envp[i] << endl;
	}

	printf("\nPor favor, pulse una tecla para terminar ...");
	_getch();
	return 0;
}
