#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <locale.h>
#include <Windows.h>
#include "pLibSS.h"

// EJERCICIO 3

int main(int argc, char *argv[])
{
	HANDLE hArchivo;

	hArchivo = CreateFile("Hola.txt",GENERIC_READ, FILE_SHARE_READ, NULL,	CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	CheckError(hArchivo == INVALID_HANDLE_VALUE, "No se pudo abrir el archivo", 1);

	// �C�mo podemos probar el efecto de dwSharedMode desde el mismo programa? FILE_SHARE_READ | FILE_SHARE_WRITE	


	CloseHandle(hArchivo); // Poner aqu� un breakpoint y ver que el archivo se crea, y no lo podemos abrir desde otra aplicaci�n,
	hArchivo = NULL;

	printf("\nPulse una tecla para terminar\n");  //Solo para depurar. Quitar si no es necesario
	getchar();
	return 0;
}




