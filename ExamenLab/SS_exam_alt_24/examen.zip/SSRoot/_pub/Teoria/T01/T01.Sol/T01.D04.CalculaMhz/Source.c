int a = 10;
