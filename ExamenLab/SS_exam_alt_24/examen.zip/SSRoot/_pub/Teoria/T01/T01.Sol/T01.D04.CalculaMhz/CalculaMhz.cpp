// Ejercicio final pr�ctica 0
// Funciona cambiando ESPERA_MS a 2000 ms?
#define ESPERA_MS (500)
void ImprimeGhz() {
	int antes, ahora;
	double VelocidadCPUGhz;

	antes = __rdtsc(); // Leo el valor del contador RDTSC y lo guardo
	Sleep(ESPERA_MS); // Espero un segundo
	ahora = __rdtsc();// Leo el valor del contador ahora

	VelocidadCPUGhz = (ahora - antes) / (ESPERA_MS * _1MHzEnHerzios);
	printf("\nLa frecuencia en Hz es: %d", VelocidadCPUGhz);
}
