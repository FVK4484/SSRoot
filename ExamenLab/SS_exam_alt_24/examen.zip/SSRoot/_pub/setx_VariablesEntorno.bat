REM Ajusta la variable de entorno AACom para que apunte al directorio donde est�n los includes, bibliotecas, ejemplos comunes
REM Solo hay que ejecutar este archivo una vez (a menos que se mueva de posici�n el directorio SSRoot)

setx AAComm "%cd%\_comm\\"

timeout 15
rem https://repositorio.informatica.us.es/svn/2rwh7vmy73mt3wh3thx/bb_demo_65738
