#define _CRT_SECURE_NO_WARNINGS
#include "pLibSS.h"

int Contador = 0;
// Este valor se calcula correctamente: no da tiempo a cambios de hilo en mitad de los hilos
//#define NRO_INCREMENTOS (10*100) 
#define NRO_INCREMENTOS (10*1000)
#define NRO_HILOS (10)

//Cada hilo la incrementa en 1 NRO_INCREMENTOS veces 
DWORD WINAPI Incrementa(LPVOID NoSeUsa)
{
	int i;
	for (i = 0; i<NRO_INCREMENTOS; i++)
	{
		Contador++;
	}
}

HANDLE hThreads[NRO_HILOS];

// Funci�n de entrada del proyecto "Demo-P10"
int main(int argc, char *argv[])
{
	int i;

	setlocale(LC_ALL, "Spanish");	// Indica que debe usar espa�ol como idioma por defecto

	//Crear N hilos que incrementen una variable global
	for (i = 0; i< NRO_HILOS; i++)
	{
		hThreads[i] = CreateThread(NULL, 0, Incrementa, 0, 0, NULL);
		CheckError(NULL == hThreads[i], "ERROR al crear hilo", 1);
	}
	// No vale para m�s de 64 handles WaitForMultipleObjects(NRO_HILOS, hThreads, TRUE, INFINITE);
	for (i = 0; i< NRO_HILOS; i++)
	{
		CheckError(0 != WaitForSingleObject(hThreads[i], INFINITE), "ERROR al bloquear main", 1);
	}
	printf("\n El valor del contador es %d", Contador);
	printf("\n El valor esperado es     %d", NRO_HILOS*NRO_INCREMENTOS);
	printf("\n La diferencia en los valores es %d",	NRO_HILOS*NRO_INCREMENTOS - Contador);

	printf("\nPulse tecla RETORNO para terminar\n");
	getchar();
	return 0;
}

