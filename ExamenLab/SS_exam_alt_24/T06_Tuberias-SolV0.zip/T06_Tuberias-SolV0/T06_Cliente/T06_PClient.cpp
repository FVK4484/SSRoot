﻿#define _CRT_SECURE_NO_WARNINGS
#include "T06_Cliente.h"

#define TAM_BUFFER 1000
static Dbg _dbg(true, true);
void UsaTuberia(const char* NombreP)
{
	HANDLE hPipeC;	// Handle para una instancia del pipe (cliente). 
	//char BEntrada[1000];	// Reserva para buffer de entrada

	char BSalida[TAM_BUFFER];		// Reserva para buffer de 
	char BEntrada[TAM_BUFFER];
	DWORD Leidos, Escritos, i;
	BOOL ResOperacion;

	// abre tubería...
	hPipeC = CreateFileA(NombreP, GENERIC_READ | GENERIC_WRITE, 0, 0,
		OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
	_dbg.CheckError(hPipeC == INVALID_HANDLE_VALUE, 1, "Error conectando a tubería");

	printf(" ............Cliente conectado\n");

	for (i = 0; i < 4; i++)
	{
		if (i % 2 == 0)
			sprintf(BSalida, "MENSAJE # %d (pasar a minúsculas)\n", i);
		else
			sprintf(BSalida, "mensaje # %d (pasar a mayúsculas)\n", i);

		ResOperacion = WriteFile(hPipeC, BSalida, strlen(BSalida) + 1, &Escritos, 0); // Escribe datos
		// Comprueba escritura correcta
		_dbg.CheckError(FALSE == ResOperacion || Escritos != strlen(BSalida) + 1, 2, "Error escribiendo tubería");
		printf("Enviado mensaje %d\n", i);

		ResOperacion = ReadFile(hPipeC, BEntrada,
			sizeof(BEntrada), &Leidos, 0);
		_dbg.CheckError(FALSE == ResOperacion, 3, "Error leyendo tubería");
		printf("\tRecibido %s\n", BEntrada);
	}
	CloseHandle(hPipeC);	// Cierra tubería

	printf("\nCliente desconectado...\n");

}


extern void ObtieneNombreYLlamaAEsperaTuberiaCreada(int msegs);
int main(int argc, char* argv[])
{
	setlocale(LC_ALL, "Spanish");	// Indica que debe usar español como idioma por defecto
	int msegs = 3*1000;
	printf("\nCliente espera %d segs a que el servidor comience...\n", msegs / 1000);
	ObtieneNombreYLlamaAEsperaTuberiaCreada(msegs);

	UsaTuberia("\\\\.\\pipe\\CaseConverterPipe");

	printf("\nPulse tecla RETORNO para terminar\n");
	getchar();
	return 0;
}
void EsperaTuberiaCreada(const char * nombreEv, int msegs) {
	HANDLE hEmpieza;
	DWORD res = 0xff;

	hEmpieza = CreateEventA(NULL, FALSE, FALSE, nombreEv);
	_dbg.CheckError(NULL == hEmpieza, 4, "No se pudo crear objeto de sincronización");
	res = WaitForSingleObject(hEmpieza, 3*1000);
	_dbg.CheckError(res != WAIT_OBJECT_0, 5, "\nNo se ha creado la tubería. Termina el programa cliente.\n");
}
