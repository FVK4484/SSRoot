#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <locale.h>
#include <thread>
#include <Windows.h>

#include "sslib/SSLib.h" 
#include "../v.h"
using namespace std;
using namespace ss;

extern const char* nombreEvento;