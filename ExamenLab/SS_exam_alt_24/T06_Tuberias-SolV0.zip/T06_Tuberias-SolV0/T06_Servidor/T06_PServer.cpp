﻿#define _CRT_SECURE_NO_WARNINGS
#include "T06_Servidor.h"

#define NRO_CONEXIONES_SIMULTANEAS 255
// Normalmente NRO_CONEXIONES_SIMULTANEAS y NRO_HILOS_SIRVIENDO son iguales? 
#define NRO_HILOS_SIRVIENDO 1
#define TAM_BUFFER_ENTRADA 1000
static Dbg _dbg(true, true);
int instanciaHillo = 0;

void GestionaTuberia(const char* pNombreTuberia)
{
	char BEntrada[TAM_BUFFER_ENTRADA];	// Reserva para buffer de entrada
	DWORD Leidos, Escritos;
	BOOL ResOperacion;
	HANDLE hPipe;	// Handle para una instancia del pipe. 
	hPipe = CreateNamedPipeA(pNombreTuberia,	//Nomnbre
		PIPE_ACCESS_DUPLEX,				// Modo apertura
		PIPE_TYPE_MESSAGE | PIPE_WAIT,	// Cómo funciona
		NRO_CONEXIONES_SIMULTANEAS,								// Nro. máx. de conexiones
		0,		// Tamaño de buffers salida. 0= tam. por defecto
		0,		// Idem entrada.
		5000,   // 
		0);		// lpSecurityAttributes.
	_dbg.CheckError(INVALID_HANDLE_VALUE == hPipe, 1, "Error creando tubería");        //HANDLE hEvento = CreateEvent(NULL,,, "evTuberiaCreada");  CheckError(hEvento == NULL, "No se pudo crear el objeto de sincronización", 1);// Activarlo y listo

	HANDLE hevInicio = CreateEventA(NULL, FALSE, FALSE, nombreEvento);
	_dbg.CheckError(NULL == hevInicio, 2, "No se pudo crear objeto de sincronización");
	int nroHilo = instanciaHillo++;
	printf("Servidor: Esperando conexión entrante en hilo %d...\n", nroHilo);
	SetEvent(hevInicio);
	_dbg.CheckError(FALSE == ConnectNamedPipe(hPipe, NULL), 2, "Error esperando conexion tubería");

	std::thread otro = std::thread(GestionaTuberia, pNombreTuberia);
	_dbg.CheckError(NULL == otro.native_handle(), 3, "ERROR al crear hilo");
	otro.detach();

	printf("Conectada tubería...\n");
	Beep(500, 200); // Aviso de que comienza a leer.
	while (TRUE)
	{
		ResOperacion = ReadFile(hPipe, BEntrada,
			sizeof(BEntrada), &Leidos, 0);
		if (FALSE == ResOperacion &&
			ERROR_BROKEN_PIPE == GetLastError())
			break;
		_dbg.CheckError(FALSE == ResOperacion, 4, "Error leyendo tubería");
		BEntrada[Leidos] = '\0';
		if (IsCharUpperA(BEntrada[0]) == TRUE)
			LCMapStringA(LOCALE_USER_DEFAULT, LCMAP_LOWERCASE, BEntrada, Leidos, BEntrada, Leidos);
		else if (IsCharLowerA(BEntrada[0]) == TRUE)
			LCMapStringA(LOCALE_USER_DEFAULT, LCMAP_UPPERCASE, BEntrada, Leidos, BEntrada, Leidos);

		printf("%s", BEntrada);

		Beep(1000, 200); // Aviso...
		ResOperacion = WriteFile(hPipe, BEntrada, Leidos, &Escritos, 0);
		_dbg.CheckError(FALSE == ResOperacion || Leidos != Escritos, 5, "Error escribiendo tubería");
	}
	_dbg.CheckError(FALSE == DisconnectNamedPipe(hPipe), 6, "Error desconectando conexion tubería");
	CloseHandle(hPipe); // Cierra instancia de la tubería (y la tubería)
}


// Función de entrada del proyecto 
int main(int argc, char* argv[])
{
	int i;
	const char* pNombreTuberia = "\\\\.\\pipe\\CaseConverterPipe";

	setlocale(LC_ALL, "Spanish");

	// Usado hilos (cuando se necesita más de 1 conexión simultanea)
	std::thread th[NRO_HILOS_SIRVIENDO];
	//Crear NRO_HILOS_SIRVIENDO hilos 
	for (i = 0; i < NRO_HILOS_SIRVIENDO; i++)
	{
		th[i] = std::thread(GestionaTuberia, pNombreTuberia);
		_dbg.CheckError(NULL == th[i].native_handle(), 7, "ERROR al crear hilo");
		th[i].detach();
	}

	printf("\nPulse tecla RETORNO para terminar\n");
	getchar();
	return 0;
}

