#pragma once

#define PPCAT_NX(A, B) A ## B
#define PPCAT(A, B) PPCAT_NX(A, B)
#define V T1V0

#define nombreEvento PPCAT(nombreEvento,V)
#define ObtieneNombreYLlamaAEsperaTuberiaCreada PPCAT(ObtieneNombreYLlamaAEsperaTuberiaCreada,V)
#define EsperaTuberiaCreada PPCAT(EsperaTuberiaCreada,V)