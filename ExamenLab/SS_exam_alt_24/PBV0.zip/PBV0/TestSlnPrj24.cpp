#include "TestSlnPrj24.h"
using namespace ss;

int main(int argc, char* argv[], char* envp[])
{
	setlocale(LC_ALL, "Spanish");

	Dbg dbg(true);
	// Comprueba si se han pasado los argumentos necesarios
	dbg.CheckError(argc < 3, ErrorFaltanArgumentos,
		"Faltan argumentos: debe indicar uvus, nroDePractica, y test (opcional).\n");
	dbg.CheckError(argc > 4, ErrorSobranArgumentos,
		"Sobran argumentos: debe indicar uvus, nroDePractica, y test (opcional).\n");

	VsSolutionTest solTest;

	bool modoTest = false;

	if (argc == 4)
	{
		modoTest = CompareStringA(LOCALE_SYSTEM_DEFAULT, LINGUISTIC_IGNORECASE,
			argv[3], strlen(argv[3]), "test", sizeof("test")) == CSTR_EQUAL;
	}

	int nroPractica = atoi(argv[2]);

	/* Obtiene de las variables de entorno, la ruta de Visual Studio

	* Para probar esta parte, definir el valor de la variable una variable de entorno MSDOS en
	* las opciones del proyecto, a�adiendo una l�nea como esta en (en Depuracion->Entorno):

   __DirMSBUILD__=$(MSBuildToolsPath)
	*/

	char rutaVS[MAX_PATH];
	const char* nombreVar = "__DirMSBUILD__";
	DWORD encontrada = GetEnvironmentVariableA(nombreVar, rutaVS, sizeof(rutaVS));
	dbg.CheckError(encontrada == 0, 2, "Error: No se ha encontrado la variable de entorno %s.\n", nombreVar);

	int res = solTest.CompruebaSolucion(nroPractica, argv[1], rutaVS, modoTest);

	// CompruebaSolucion devolvi� 0
	dbg.CheckError(res != 0, 1, "Soluci�n incorrecta.\n");
	printf("Soluci�n compilada correctamente.\n");

	printf("\nPor favor, pulse la tecla ENTRAR para terminar ...\n");
	(void)getchar();  // printf y getchar=> necesitan #include <stdio.h>
	return res;
}
